export default (): void => {
  console.log('Sou o módulo.');
};
