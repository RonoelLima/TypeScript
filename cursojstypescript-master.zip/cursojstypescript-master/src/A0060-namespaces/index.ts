/* eslint-disable @typescript-eslint/triple-slash-reference */
/// <reference path="modulo/module.ts" />

console.log(MeuNamespace.nomeDoNamespace);
console.log(constDoNamespace);
