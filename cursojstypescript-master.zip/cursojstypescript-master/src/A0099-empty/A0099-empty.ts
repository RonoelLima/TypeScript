// The sky is blue.
