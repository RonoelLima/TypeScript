declare namespace _ {
  interface LoDashStatic {
    mul(array: number[]): number;
  }
}

declare namespace NodeJS {
  interface Global {
    MINHAGLOBAL: string;
  }
}
